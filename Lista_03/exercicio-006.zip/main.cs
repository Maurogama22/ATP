//6. A prefeitura de uma cidade fez uma pesquisa entre seus habitantes, coletando dados sobre o
//salário e número de filhos de cada habitante. A prefeitura deseja saber:
//a) A média do salário da população;
// /b) A média do número de filhos;
//c) O maior salário;
//d) O percentual de pessoas com salário até R$100,00.
//O final da leitura de dados se dará com a entrada de um salário negativo
using System;

class Program
{
    static void Main(string[] args)
    {
        double salarioTotal = 0;
        int numeroFilhosTotal = 0;
        int contadorPessoasSalarioAte100 = 0;
        double maiorSalario = double.MinValue;
        int contadorHabitantes = 0;

        while (true)
        {
            Console.Write("Digite o salário do habitante (ou um valor negativo para encerrar): ");
            double salario = double.Parse(Console.ReadLine());

            if (salario < 0)
            {
                break;
            }

            Console.Write("Digite o número de filhos do habitante: ");
            int numeroFilhos = int.Parse(Console.ReadLine());

            salarioTotal += salario;
            numeroFilhosTotal += numeroFilhos;
            contadorHabitantes++;

            if (salario > maiorSalario)
            {
                maiorSalario = salario;
            }

            if (salario <= 100)
            {
                contadorPessoasSalarioAte100++;
            }
        }

        if (contadorHabitantes > 0)
        {
            double mediaSalario = salarioTotal / contadorHabitantes;
            double mediaFilhos = (double)numeroFilhosTotal / contadorHabitantes;
            double percentualSalarioAte100 = (double)contadorPessoasSalarioAte100 / contadorHabitantes * 100;

            Console.WriteLine($"Média do salário da população: {mediaSalario:C}");
            Console.WriteLine($"Média do número de filhos: {mediaFilhos:F2}");
            Console.WriteLine($"Maior salário: {maiorSalario:C}");
            Console.WriteLine($"Percentual de pessoas com salário até R$100,00: {percentualSalarioAte100:F2}%");
        }
        else
        {
            Console.WriteLine("Nenhum dado foi inserido.");
        }
    }
}