//8. Faça um programa que imprima os L primeiros elementos da série de Fibonacci. Por
//exemplo, se o usuário digitou o número 40, deverão ser apresentados os 40 números da
//sequência na tela.
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Digite o número de elementos da sequência de Fibonacci a serem exibidos: ");
        int L = int.Parse(Console.ReadLine());

        if (L <= 0)
        {
            Console.WriteLine("Número inválido. O número deve ser maior que zero.");
        }
        else
        {
            Console.WriteLine("Sequência de Fibonacci:");

            if (L >= 1)
            {
                Console.WriteLine("0");
            }

            if (L >= 2)
            {
                Console.WriteLine("1");
            }

            int a = 0;
            int b = 1;
            for (int i = 3; i <= L; i++)
            {
                int proximo = a + b;
                Console.WriteLine(proximo);
                a = b;
                b = proximo;
            }
        }
    }
}