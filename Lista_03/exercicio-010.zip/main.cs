//10. Escreva o algoritmo para um empresário que deseja fazer o levantamento do lucro das
//mercadorias que ele comercializa. O usuário deve informar o preço de compra e de venda de
//cada mercadoria. O algoritmo deve interromper a leitura quando o usuário informar o preço
//de compra igual a 0. O algoritmo deve:
//a) Determinar e escrever quantas mercadorias proporcionaram:
//i) Lucro < 10%
//ii) 10% <= Lucro <= 20%
//iii) Lucro > 20%
//b) Determinar e escrever o valor total de compra e de venda de todas as mercadorias,
using System;

class Program
{
    static void Main(string[] args)
    {
        double totalCompra = 0;
        double totalVenda = 0;
        int lucroMenor10 = 0;
        int lucroEntre10e20 = 0;
        int lucroMaior20 = 0;

        while (true)
        {
            Console.Write("Digite o preço de compra da mercadoria (ou 0 para encerrar): ");
            double precoCompra = double.Parse(Console.ReadLine());

            if (precoCompra == 0)
            {
                break;
            }

            Console.Write("Digite o preço de venda da mercadoria: ");
            double precoVenda = double.Parse(Console.ReadLine());

            totalCompra += precoCompra;
            totalVenda += precoVenda;

            double lucro = ((precoVenda - precoCompra) / precoCompra) * 100;

            if (lucro < 10)
            {
                lucroMenor10++;
            }
            else if (lucro >= 10 && lucro <= 20)
            {
                lucroEntre10e20++;
            }
            else
            {
                lucroMaior20++;
            }
        }

        Console.WriteLine("\nRelatório de lucros:");
        Console.WriteLine($"Quantidade de mercadorias com lucro < 10%: {lucroMenor10}");
        Console.WriteLine($"Quantidade de mercadorias com 10% <= lucro <= 20%: {lucroEntre10e20}");
        Console.WriteLine($"Quantidade de mercadorias com lucro > 20%: {lucroMaior20}");
        Console.WriteLine($"Valor total de compra das mercadorias: {totalCompra:C}");
        Console.WriteLine($"Valor total de venda das mercadorias: {totalVenda:C}");
    }
}