//05Escrever um algoritmo que lê um valor N inteiro e positivo e que calcula e escreve o valor
//de E:
//E = 1 + 1 / 1! + 1 / 2! + 1 / 3! + .... + 1 / N!
    using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Digite um número inteiro e positivo para calcular E: ");
        int N = int.Parse(Console.ReadLine());

        if (N < 0)
        {
            Console.WriteLine("Número inválido. O número deve ser positivo.");
        }
        else
        {
            double E = CalcularE(N);
            Console.WriteLine($"O valor de E é: {E}");
        }
    }

    static double CalcularE(int N)
    {
        double E = 1.0;

        for (int i = 1; i <= N; i++)
        {
            E += 1.0 / CalcularFatorial(i); 
        }

        return E;
    }

    static long CalcularFatorial(int n)
    {
        
        if (n == 0)
        {
            return 1;
        }

        long fatorial = 1;

        
        for (int i = n; i > 0; i--)
        {
            fatorial *= i;
        }

        return fatorial;
    }
}