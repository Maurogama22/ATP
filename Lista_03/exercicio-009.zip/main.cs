//9. Faça um programa que imprima a soma de todos os elementos da série de Fibonacci
//menores que L. O valor de L deve ser informado pelo usuário.
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Digite o valor limite para a soma dos elementos da série de Fibonacci: ");
        int L = int.Parse(Console.ReadLine());

        if (L <= 0)
        {
            Console.WriteLine("Número inválido. O número deve ser maior que zero.");
        }
        else
        {
            int soma = 0;
            int a = 0;
            int b = 1;
            while (a < L)
            {
                soma += a;
                int proximo = a + b;
                a = b;
                b = proximo;
            }

            Console.WriteLine($"A soma de todos os elementos da série de Fibonacci menores que {L} é: {soma}");
        }
    }
}