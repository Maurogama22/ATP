//3. Faça um programa que receba dez números e verifique se eles são divisíveis por 3 e 9 (ao
//mesmo tempo), por 2 e por 5. Caso algum número não seja divisível por nenhum desses
//números mostre a mensagem “Número não é divisível pelos valores”. Apresente também ao
//final a quantidade de números divisíveis por 3 e 9, por 2 e por 5.
//OBS:
//Divisibilidade por 2: todo número par (terminado em 0, 2, 4, 6, 8) é divisível por 2.
//Divisibilidade por 3: um número é divisível por 3, se a soma de seus algarismos é divisível
//por 3. Exemplos: 18 é divisível por 3 pois 1+8=9 que é divisível por 3; 576 é divisível por
//3 pois: 5+7+6=18 que é divisível por 3; mas 134 não é divisível por 3, pois 1+3+4=8 que
//não é divisível por 3.
//Divisibilidade por 5: um número é divisível por 5 se o seu algarismo final é zero ou 5.
//Divisibilidade por 9: se a soma de todos os algarismos de um número for divisível por 9,
//então esse número é divisível por 9. Exemplo: o número 6.282 é divisível por 9, pois 6 + 2
//+ 8 + 2 = 18.
using System;

class Program
{
    static void Main(string[] args)
    {
        
        int[] numeros = new int[10];  
        int divPor3e9 = 0;
        int divPor2 = 0;
        int divPor5 = 0;
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Digite o {i+1}º número: ");
            numeros[i] = int.Parse(Console.ReadLine());
            if (numeros[i] % 3 == 0 && numeros[i] % 9 == 0)
            {
                divPor3e9++;
            }
            if (numeros[i] % 2 == 0)
            {
                divPor2++;
            }
            if (numeros[i] % 5 == 0)
            {
                divPor5++;
            }
        }
        Console.WriteLine("\nQuantidade de números divisíveis por:");
        Console.WriteLine($"- 3 e 9 ao mesmo tempo: {divPor3e9}");
        Console.WriteLine($"- 2: {divPor2}");
        Console.WriteLine($"- 5: {divPor5}");
    }
}