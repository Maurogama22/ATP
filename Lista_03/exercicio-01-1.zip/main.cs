// 1. Fazer um programa que leia uma sequência de valores inteiros fornecida pelo usuário em
//uma linha de entrada e conte o número de valores positivos, negativos e zeros.
using System;

class Program
{
    static void Main(string[] args)
    {

        Console.WriteLine("digite uma sequencia de numeros inteiros:");
        string input = Console.ReadLine();


        string[] numbers = input.Split(' ');


        int positiveCount = 0;
        int negativeCount = 0;
        int zeroCount = 0;

        foreach (string number in numbers)
        {
            int num = int.Parse(number);

            
             if (num > 0)
            {
                positiveCount++;
            }
            else if (num < 0)
            {
                negativeCount++;
            }
            else
            {
                zeroCount++;
            }
        }

        
         Console.WriteLine($"Números positivos: {positiveCount}");
        Console.WriteLine($"Números negativos: {negativeCount}");
        Console.WriteLine($"Zeros: {zeroCount}");
    }
}