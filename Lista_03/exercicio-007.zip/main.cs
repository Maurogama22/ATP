//7. Escreva um algoritmo que lê um valor n inteiro e positivo e que calcula a seguinte soma:
//S = 1 + 1/2 + 1/3 + 1/4 + ... + 1/n
//O algoritmo deve escrever cada termo gerado e o valor final de S
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Digite um número inteiro e positivo para calcular a soma: ");
        int n = int.Parse(Console.ReadLine());

        if (n <= 0)
        {
            Console.WriteLine("Número inválido. O número deve ser positivo.");
        }
        else
        {
            double soma = 0;

            Console.WriteLine("Termos gerados:");
            for (int i = 1; i <= n; i++)
            {
                double termo = 1.0 / i;
                soma += termo;
                Console.WriteLine($"1/{i} = {termo}");
            }

            Console.WriteLine($"\nO valor final de S é: {soma:F2}");
        }
    }
}