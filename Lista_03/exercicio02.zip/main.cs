using System;

class Program
{
    static void Main(string[] args)
    {
       
        Console.WriteLine("Insira uma sequência de números inteiros separados por espaço:");
        string input = Console.ReadLine();

       
        string[] numbers = input.Split(' ');

       
        int positiveCount = 0;
        int negativeCount = 0;
        int zeroCount = 0;

       
        foreach (string number in numbers)
        {
          
            int num = int.Parse(number);

        
            if (num > 0)
            {
                positiveCount++;
            }
            else if (num < 0)
            {
                negativeCount++;
            }
            else
            {
                zeroCount++;
            }
        }

        
        int totalCount = numbers.Length;

      
        double positivePercentage = (double)positiveCount / totalCount * 100;
        double negativePercentage = (double)negativeCount / totalCount * 100;
        double zeroPercentage = (double)zeroCount / totalCount * 100;

      
        Console.WriteLine($"Números positivos: {positiveCount} ({positivePercentage:F2}%)");
        Console.WriteLine($"Números negativos: {negativeCount} ({negativePercentage:F2}%)");
        Console.WriteLine($"Zeros: {zeroCount} ({zeroPercentage:F2}%)");
    }
}